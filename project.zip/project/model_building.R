setwd("D:\\DataScience\\Final_Project")

library(readr)
library(plyr)
library(dplyr)
library(data.table)
library(caret)
library(tm)
library(SnowballC)
library(fuzzyjoin)

train_data <- read_tsv(file.choose())
test_data <- read_tsv(file.choose())  

train_data <- train_data[-1]
test_data <- test_data[-1]

data <- rbind(train_data,test_data) 

nrow(data)
View(data)
str(data)
sum(is.na(data))
summary(data)

data <- na.omit(data)
sum(is.na(data))

data <- as.data.frame(data)
View(data)

data <- data[-grep('users found this comment helpful.',data$condition),]
View(data)

data$condition <- as.factor(data$condition)
data$drugName <- as.factor(data$drugName)
#data$rating <- as.factor(data$rating)

s <- read_tsv(gzfile(file.choose()))  
View(s)
s <- as.data.frame(s)
s <- s[,4]
ts <- as.data.frame(s[!duplicated(s)])
class(ts)
names(ts)[names(ts) ==  "s[!duplicated(s)]"] <- "Side_Effects"
View(ts)
write.table(ts[-1,],file="D:\\DataScience\\Final_Project\\side_effects.txt",row.names = FALSE,quote = FALSE)

seff <- readLines("D:\\DataScience\\Final_Project\\side_effects.txt") 
View(top10CondData)


View(top10CondData.review)
top10CondData.review <- data.frame(top10CondData$review)
names(top10CondData.review)[names(top10CondData.review)=="top10CondData.review"] <- "rvw"
top10CondData.review$rvw = as.character(top10CondData.review$rvw)
top10CondData.review <- unique(top10CondData.review)

ts$Side_Effects <- as.character(ts$Side_Effects) 
ts = unique(ts)
View(ts)

top10CondData.review$Side_Effects <- ""

for(i in 1:dim(top10CondData.review)[1]) {
  x <- agrep(top10CondData.review$rvw[i], ts$Side_Effects,
             ignore.case=TRUE, value=TRUE,
             max.distance = 0.1, useBytes = TRUE)
  x <- paste0(x,"")
  top10CondData.review$Side_Effects[i] <- x
}

 


rvmatch <- top10CondData[seff %in% top10CondData$review,] 
View(rvmatch)

dd <- data[data$condition=='Birth Control',]
View(dd)

mean(dd$usefulCount)

category_class <- ifelse(dd$usefulCount>round(mean(dd$usefulCount),0)& dd$rating>6 
                         ,"Positive",
                         ifelse(dd$usefulCount<round(mean(dd$usefulCount),0)& dd$rating<5,
                                "Negative","Neutral"))

category_class <- as.factor(category_class)

category_id <- ifelse(dd$usefulCount>round(mean(dd$usefulCount),0) & dd$rating>6 
                      ,1,
                      ifelse(dd$usefulCount<round(mean(dd$usefulCount),0)& dd$rating<5,
                             2,3))

category_id <- as.factor(category_id)

dd <- cbind(dd,category_class,category_id)

# library(lubridate)
# top10CondData$date <- mdy(top10CondData$date)

## taking only data from year 2015.
# top10CondData <-  subset(top10CondData,date > '2014-12-31')
# View(top10CondData)

set.seed(101)
train <- sample(nrow(dd), .7 * nrow(dd), replace = FALSE)
test  <- sample(nrow(dd), .3 * nrow(dd), replace = FALSE)

train_dat <- dd[train,]
test_dat <- dd[test,]

train_corpus <- VCorpus(VectorSource(train_dat$review))
train_corpus <- tm_map(train_corpus,tolower)
train_corpus <- tm_map(train_corpus,removePunctuation)
train_corpus <- tm_map(train_corpus,removeNumbers)
train_corpus <- tm_map(train_corpus,removeWords,c(stopwords("en"),stop))
train_corpus <- tm_map(train_corpus,stripWhitespace)
train_corpus <- tm_map(train_corpus,stemDocument)
train_corpus <- tm_map(train_corpus,PlainTextDocument)
rm(dtm_matrix)
dtm_train <- DocumentTermMatrix(train_corpus)
train_corpus <- removeSparseTerms(dtm_train, 0.8)

rm(dtm_train_matrix)

dtm_train_matrix <- as.matrix(train_corpus)
dtm_train_matrix <- cbind(dtm_train_matrix, train_dat$category_id)
View(dtm_train_matrix)
colnames(dtm_train_matrix)[ncol(dtm_train_matrix)] <- "category"

rm(training_set)

training_set <- as.data.frame(dtm_train_matrix)
training_set$category <- as.factor(training_set$category)
View(training_set)

model.svm <- ksvm(category ~ .,data = training_set , kernel = "vanilladot" )

ddsvm <- svm(category~.,training_set,type='C-classification',kernel = 'radial')
ddsvm

summary(ddsvm)

# predi <- predict(ddsvm,training_set)
# View(predi)
# mean(predi==training_set$category)
# 
# table(predi,training_set$category)
# #kernlab::plot(predi,dd$category_id)
# 
# training_set <- cbind(training_set,predi)
# View(training_set)
# 
# View(cbind(dd,predi))

library(gmodels)
CrossTable(predi , dd$category_id)
View(test_dat)
NROW(train_dat)
test_corpus <- VCorpus(VectorSource(test_dat$review))
test_corpus <- tm_map(test_corpus,tolower)
test_corpus <- tm_map(test_corpus,removePunctuation)
test_corpus <- tm_map(test_corpus,removeNumbers)
test_corpus <- tm_map(test_corpus,removeWords,c(stopwords("en"),stop))
test_corpus <- tm_map(test_corpus,stripWhitespace)
test_corpus <- tm_map(test_corpus,stemDocument)
test_corpus <- tm_map(test_corpus,PlainTextDocument)

rm(dtm_test)
dtm_test <- DocumentTermMatrix(test_corpus)
test_corpus <- removeSparseTerms(dtm_test, 0.8)

dtm_test_matrix <- as.matrix(test_corpus)
View(dtm_train_matrix)
View(dtm_test_matrix)

model.pred <- predict(model.svm , newdata = dtm_test_matrix)


predi <- predict(ddsvm, newdata = dtm_test_matrix)
# predi_df <- as.data.frame(factor(c(1,2,3),levels=c("Negative","Neutral","Positive")))
View(test_dat)
