library(shiny)
library(shinydashboard)
library(shinyWidgets)
library(shinyjs)


shinyUI(
    dashboardPage(
      dashboardHeader(title = "Drug Effectiveness Review",titleWidth = 300,disable = FALSE),
        dashboardSidebar(width = 300,
            sidebarMenu(id="tabs",style = "position: fixed; overflow: visible;",
            menuItem("How to Use",tabName = "use_it",icon = icon("question")),
            menuItem("Search",tabName = "search",icon=icon("search")),
            menuItem("Word Cloud",tabName = "word_cloud",icon=icon("cloud")),
            menuItem("Sentiment Analysis",tabName = "Analysis",icon=icon("smile")),
            menuItem("Model Accuracy",tabName = "model",icon=icon("tachometer-alt")),
            menuItem("Raw Data",tabName = "raw_data",icon=icon("table"))
            
        )),
        dashboardBody(
          useShinyjs(),
            fluidPage(
            tags$style('.container-fluid {
                             background-color: #FFFFFF;
              }'),
            tabItems(
              tabItem(tabName = "use_it",fluidPage(
                
                h2('How does this interface work?', class = 'left'),
                
                h4(
                  'The interface is divided into 5 tabs presented in the menu on the left:',
                  tags$b('Search'),",",tags$b('Word Cloud'),",",
                  tags$b('Sentiment Analysis'),",",tags$b('Model Accuracy'),"and",tags$b('Raw Data'),'.',
                  class = 'left',sep=""
                ),
                
                br(),
                
                h4(
                  icon("search"),tags$b('Search'),
                  br(),
                  'In this Section just type in the condition like', tags$b("Birth Control") ,'or', tags$b("Pain"), 'etc.After
                  that radio buttons will pop up and you can select anyone to see the results containing your', 
                  tags$b('Medicine'),'name with the', tags$b("Rating"),"Don't worry if you don't know the spelling... still
                  it will show you the results for the following condition you have wrote.",
                  class = 'left'
                ),
                
                br(),
                
                h4(
                  icon("cloud"),tags$b('Word Cloud'),
                  br(),
                  'Once you have finished type in your condition in the', icon("search"),tags$b('Search'),'the word cloud',
                  icon("cloud"),'will be create with respect to its review that the medicines has',
                  class = 'left'
                ),
                
                br(),
              
                h4(
                  icon("smile"),tags$b('Sentiment Analysis'),
                  br(),
                  'you will be able to see the sentiments plot that is related to the reviews of all the medicines 
                  of the type that you have choosed',
                  class = 'left'
                ),
                
                br(),
                
                h4(icon("tachometer-alt"),tags$b('Model Accuracy'),
                   br(),
                  'You can check your Model Accuracy with different types of Algorithms
                       by selecting one of the provided Algorithms',
                  class = 'left'
                ),
                
                br(),
                
                h4(icon("table"),tags$b('Raw Data'),
                  'You can see the data that is being used for the Drug Review Effectiveness. ',
                  class = 'left'
                ),
                
                br()
              )),   
              
              
              tabItem(tabName = "word_cloud",
                         h1("Word Cloud"),
                         fluidRow(
                     column(
                         width = 6,
                         box(
                             width = 12,plotOutput("cloud"))),
                     column(
                         width=5,
                         box(
                             radioButtons("type","Select Type: ",c("Positive","Negative","Mixed")
                                           ,selected = "Mixed"),
                             actionButton("update","Create Word Cloud")
                         )
                     ),
                     box(sliderInput("n1","Max.Number of Frequency Words",1,800,600)),
                     box(sliderInput("n2","Min.of Frequency of Words",1,10,3))
                  )),
                 
              tabItem(tabName = "search",
                      h1("Search"),
                      fluidRow(
                        br(),
                        
                        box(width = 12,column(12, align="center",
                        selectizeInput(
                          inputId = "srch", label = "What is your condition??",
                          options= list(placeholder = "enter your condition name",maxItems=1),
                          choices = unique(top_data$condition),
                          #onInitialize=I('function(){this.setValue(" ");}'),
                          multiple = TRUE,
                          # btnSearch = icon("search"),
                          # btnReset = icon("remove"),
                          width = "450px"
                        ))),
                        
                        box(width = 12,column(12, align="center",
                        conditionalPanel(
                          condition = "input.srch.length > 0",
                          prettyRadioButtons(
                            inputId = "show_words",
                            selected ="white",
                            label = "Split Drugs by:",
                            thick = TRUE,
                            inline = TRUE, 
                            choices = c("Effective"="green", "Neutral"="blue", "Adverse"="red","None" = "white"),
                            animation = "pulse",
                            status = "info"
                          ) 
                        )
                      )),
                      box(width = 12,column(12, align="center",
                                            DT::dataTableOutput("drug")
                      ))
                    )),
                 
                 
                 tabItem(tabName = "model",
                         h1("Model Accuracy"),
                         fluidRow(
                           
                             column(
                                 width = 6,
                                 box(h3("Accuracy of Model is : ",textOutput("mod")),
                                     width = 12)),
                             column(
                                 width=6,
                                 box(
                                     radioButtons("model_type","Select Type: ",c("SVM","Random Forest",
                                                                                 "Desicion Tree","Logistic Regression")
                                                  ,selected = "Logistic Regression"),
                                     actionButton("check","Check Accuracy")
                                 )
                             ),
                             box(sliderInput("n11","Adjust Training Ratio",0.1,1.0,0.6)),
                             box(sliderInput("n22","Adjust Testing Ratio",0.1,1.0,0.4))
                         )),
                 
                 
                 
                     
                 tabItem(tabName = "Analysis",fluidRow(
                     h1("Sentiment Analysis"),
                     plotOutput("graph")
                 )),
                 tabItem(tabName = "raw_data",fluidRow(
                     h1("Raw Data"),
                     tabsetPanel(id="tabset",selected = "t1",
                                 tabPanel("Data File",DT::dataTableOutput("dt")),
                                 tabPanel("Predicted Preview File",DT::dataTableOutput("dd"))
                                 )
                 ))
             )
        )
      )
    )
)
