library(readr)
library(dplyr)
library(tm)
library(caret)
library(SnowballC)
library(data.table)
library(C50)
library(randomForest)

train_corp <- function(train_dat){
stop <- scan("D:/DataScience/Final_Project/stop.txt",what="character",comment.char = ";")

train_corpus <- VCorpus(VectorSource(train_dat$review))
train_corpus <- tm_map(train_corpus,tolower)
train_corpus <- tm_map(train_corpus,removePunctuation)
train_corpus <- tm_map(train_corpus,removeNumbers)
train_corpus <- tm_map(train_corpus,removeWords,c(stopwords("en"),stop))
train_corpus <- tm_map(train_corpus,stripWhitespace)
train_corpus <- tm_map(train_corpus,stemDocument)
train_corpus <- tm_map(train_corpus,PlainTextDocument)

dtm_train <- DocumentTermMatrix(train_corpus)
train_corpus <- removeSparseTerms(dtm_train, 0.8)

dtm_train_matrix <- as.matrix(train_corpus)
dtm_train_matrix <- cbind(dtm_train_matrix, train_dat$category_id)
colnames(dtm_train_matrix)[ncol(dtm_train_matrix)] <- "y"

training_set_top10Cond <- as.data.frame(dtm_train_matrix)
training_set_top10Cond$y <- as.factor(training_set_top10Cond$y)

training_set_top10Cond
}

test_corp <- function(test_dat){
  
stop <- scan("D:/DataScience/Final_Project/stop.txt",what="character",comment.char = ";")
  
test_corpus <- VCorpus(VectorSource(test_dat$review))
test_corpus <- tm_map(test_corpus,tolower)
test_corpus <- tm_map(test_corpus,removePunctuation)
test_corpus <- tm_map(test_corpus,removeNumbers)
test_corpus <- tm_map(test_corpus,removeWords,c(stopwords("en"),stop))
test_corpus <- tm_map(test_corpus,stripWhitespace)
test_corpus <- tm_map(test_corpus,stemDocument)
test_corpus <- tm_map(test_corpus,PlainTextDocument)

 test_corpus
}

test_dtm <- function(test_corpus){

dtm_test <- DocumentTermMatrix(test_corpus)
test_corpus <- removeSparseTerms(dtm_test, 0.8)
as.matrix(test_corpus)

}

### SVM Model ###

build_svm <- function(training_set_top10Cond , test_dat,dtm_test_matrix){

review_top10Cond_model <- train(y ~., data = trn, method = 'svmLinear3')

# Make predictions
model_top10Cond_result <- predict(review_top10Cond_model, newdata = dtm_test_matrix)
# View(model_top10Cond_result)
# table(model_top10Cond_result , test_dat$category_id)

bind <<- NULL
bind <<-as.data.frame(cbind(test_dat,model_top10Cond_result))

# Model accuracy
round(mean(model_top10Cond_result == as.numeric(test_dat$category_id))*100,2)
} 

#### Regression model ####

build_log <- function(training_set_top10Cond , test_dat,dtm_test_matrix){

model <- nnet::multinom(y ~., data = training_set_top10Cond)
summary(model)
# Make predictions
predicted.classes <- model %>% predict(dtm_test_matrix)
bind <<- NULL
bind <<-as.data.frame(cbind(test_dat,predicted.classes))
# Model accuracy

round(mean(predicted.classes == as.numeric(test_dat$category_id))*100,2)
}



#### Decision Tree #####
build_dec <- function(training_set_top10Cond , test_dat,dtm_test_matrix){
train.tree <- C5.0(y ~ .,data = training_set_top10Cond)  
pred.train <- predict(train.tree , as.data.frame(dtm_test_matrix))
bind <<- NULL
bind <<-as.data.frame(cbind(test_dat,predi.train))

## Accuraccy model
round(mean(pred.train == as.numeric(test_dat$category_id))*100,2)
}

#### Random Forest ####

build_rdm <- function(training_set_top10Cond , test_dat,dtm_test_matrix){
fit.forest <- randomForest(y~.,data=training_set_top10Cond,na.action = na.roughfix ,importance = TRUE)
pred.trn <- predict(fit.forest , as.data.frame(dtm_test_matrix))
bind <<- NULL
bind <<-as.data.frame(cbind(test_dat,pred.trn))

## Accuraccy model

round(mean(pred.trn == as.numeric(test_dat$category_id))*100,2)
}