library(shiny)
library(shinydashboard)
library(shinyjs)
library(shinyWidgets)

options(shiny.maxRequestSize = 100*1024^2)

source("global.R")
source("md.R")

shinyServer(function(input, output, session) {
    input_file <- reactive({
        input$update
        isolate({
            withProgress({
                setProgress(message = "Processing Text...")
                wc_text <- words_srch()
                 if(is.null(wc_text)){
                     wc_text <- return() 
                 }
                 # else{
                 #     wc_text <- "A tag cloud (word cloud or wordle or weighted list in visual design) is 
                 #        a novelty visual representation of text data, typically used to depict keyword
                 #        metadata (tags) on websites, or to visualize free form text. 
                 #        Tags are usually single words, and the 
                 #        importance of each tag is shown with font size or color." 
                 # }
                 # 
                if(input$type == "Positive"){
                    corp_data <- clean_data(wc_text)
                    sent_data <- pos_data(corp_data)
                }
                
                
                else if(input$type == "Negative"){
                    corp_data <- clean_data(wc_text)
                    neg <- neg_data(corp_data)
                }
                
                else{
                    corp_data <- clean_data(wc_text)
                }  
            })
        })  
    })
    
        
        wordcloud_rep <- repeatable(wordcloud)
        
        output$cloud <- renderPlot({
            withProgress({
                setProgress(message = "Creating Plot....")
                v <- input_file() 
                if(is.null(v)) return()
                else{
                wordcloud_rep(names(v),v,scale = c(4,0.5),
                              min.freq = input$n2,max.words = input$n1,
                              rot.per = 0.3,
                              colors = brewer.pal(8,"Set1"))
                }
            })
        })
    
        
                # output$txt <- renderTable({
                #     if(is.null(input$file)){
                #         "OOPs No Text Found!!!"
                #     }
                #     
                #     else{
                #      readLines(input$file$datapath)
                #     }
                # })
                
                output$dt <- DT::renderDataTable({
                    
                    if(is.null(top_data)){
                        return()
                    }
                    
                    else{
                        
                    top_data
                    }
                })
                
                
                output$dd <- DT::renderDataTable({
                        if(!is.null(bind)) bind
                        else return()
                    })
                
                    
                output$graph <- renderPlot({
                    # ws <- words_srch()
                    #   if(!is.null(ws)){
                    #      sent(ws)
                    # }
                    
                    srch_drug <- srch(input$srch)
                    
                    if(input$show_words == "green"){
                        y <- effect_wrd(srch_drug)
                        sent(y)
                    }
                    else if(input$show_words == "blue"){
                        neu_wrd(srch_drug)
                    }
                    else if(input$show_words == "red"){
                        adv_wrd(srch_drug)
                    }
                    
                     else{
                        
                        message("Oops No Data Loaded!!!")
                        paste("text file not uploaded!!!")
                        return()
                    }
                })
                    
                acc <- reactive({
                    input$check
                    
                        withProgress({
                            setProgress(message = "Processing Data...")
                        
                            if(is.null(top_data)) return()
                            train <- sample(nrow(top_data), input$n11 * nrow(top_data), replace = FALSE)
                            test  <- sample(nrow(top_data), input$n22 * nrow(top_data), replace = FALSE)
                            
                            train_dat <- top_data[train,]
                            test_dat <- top_data[test,]
                            trn <- train_corp(train_dat)
                            tst <- test_corp(test_dat)
                            test_dtm_matrix <- test_dtm(tst)
                            
                            if(input$model_type == "SVM"){
                                svm_mod <- build_svm(trn,test_dat,test_dtm_matrix)
                            }
                            
                            
                            else if(input$model_type == "Random Forest"){
                                rdm_mod <- build_rdm(trn,test_dat,test_dtm_matrix)
                            }
                            
                            
                            else if(input$model_type == "Decision Tree"){
                                dec_mod <- build_dec(trn,test_dat,test_dtm_matrix)
                            }  
                            else {
                                log_mod <- build_log(trn,test_dat,test_dtm_matrix)
                            }  
                            
                    })
                    
                      
                })
                
            output$mod <- renderText({
                    withProgress({
                        setProgress(message = "Showing Accuracy Please Wait....")
                         paste(acc(),"%")
                        
                    })
                })
                
            
            sr <- reactive({
                
                srch_drug <- srch(input$srch)
                
                if(input$show_words == "green"){
                    effect(srch_drug)
                }
                else if(input$show_words == "blue"){
                    neu(srch_drug)
                }
                else if(input$show_words == "red") {
                    adv(srch_drug)
                }
                else{
                    return()
                }
            })
            
            words_srch <- reactive({
                
                srch_drug <- srch(input$srch)
                
                if(input$show_words == "green"){
                    effect_wrd(srch_drug)
                }
                else if(input$show_words == "blue"){
                    neu_wrd(srch_drug)
                }
                else if(input$show_words == "red"){
                    adv_wrd(srch_drug)
                }
                else {
                    return()
                }
                
            })
            
           
            output$drug <- DT::renderDataTable({
                
                if(input$show_words == "None" | length(input$srch)<=0 ) return()
                
                else if(input$show_words == "green"){
                    DT::datatable(sr())    
                }
                else if(input$show_words == "blue"){
                    DT::datatable(sr())
                }
                else if(input$show_words == "red"){
                    DT::datatable(sr())
                }
               
            })
          
                
})