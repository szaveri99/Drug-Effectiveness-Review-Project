setwd("D:\\DataScience\\Final_Project")

library(readr)
library(plyr)
library(dplyr)
library(data.table)
library(caret)
library(arsenal)

library(plotrix)
library(RColorBrewer)
library(tm)
library(slam)
library(wordcloud)
library(ggplot2)
library(syuzhet)
library(topicmodels)

train_data <- read_tsv(file.choose())
test_data <- read_tsv(file.choose())  

train_data <- train_data[-1]
test_data <- test_data[-1]

data <- rbind(train_data,test_data) 
nrow(data)
View(data)
str(data)
sum(is.na(data))
summary(data)

data <- na.omit(data)
sum(is.na(data))

data <- as.data.frame(data)
View(data)

data <- data[-grep('users found this comment helpful.',data$condition),]
View(data)

neg <- scan(file.choose(),what="character",comment.char=";")
pos <- scan(file.choose(),what="character",comment.char = ";")
stop <- scan(file.choose(),what="character",comment.char = ";")
View(stop)


## word cloud for top 5 drugs with rating > 8.

top10Drug <- as.data.frame(sort(table(data$drugName),decreasing=TRUE)[1:10])
names(top10Drug)[c(1,2)] <- c("drugName","total_count")
top10DrugData <- data[data$drugName %in% top10Drug[1:5,"drugName"] & data$rating > 8,] 
View(top10DrugData)

write.table(top10DrugData[,"review"],file="top10drugs.txt",row.names = F)
top10dd <- readLines("top10drugs.txt")
top10dd <- readLines(file.choose())

head(top10dd)

corpusdd <- top10dd
corpusdd <- Corpus(VectorSource(corpusdd))
corpusdd <- tm_map(corpusdd , tolower)
corpusdd <- tm_map(corpusdd , removePunctuation)
corpusdd <- tm_map(corpusdd , removeNumbers)
corpusdd <- tm_map(corpusdd , removeWords , c(stopwords("english"),stop))
corpusdd <- tm_map(corpusdd , stripWhitespace)
corpusdd <- tm_map(corpusdd , stemDocument)
inspect(corpusdd[1:5])
length(corpusdd)

corpusdd
tdm <- TermDocumentMatrix(corpusdd)

## correlations 
findAssocs(tdm,"insert",0.6)
findAssocs(tdm,"protect",0.75)
findAssocs(tdm,"birth",0.8)

tdm <- as.matrix(tdm)
rowTotals <- apply(tdm , 1, sum)
tdm.new   <- tdm[rowTotals> 0, ]
tdm.new[1:10,1:20]

w <- sort(rowSums(tdm.new) , decreasing = TRUE)
View(names(w))
v <- data.frame(word = names(w) , freq = w)

## mixed word cloud
wordcloud(words = names(w) , freq = w,
          max.words = 600 , min.freq = 6,
          scale = c(8,0.3),rot.per = 0.7,
          colors = w)

## top 20 most frequent words used 
ggplot(v[1:20,],aes(x=word,y=freq))+geom_bar(stat = 'identity',fill= "lightgreen")+
  theme(axis.text.x = element_text(angle = 90))+ylab("Word Frequencies")+
  title("Top 20 most frequent words")


# View(top10dd)
# head(c(names(w)))

# ?wordcloud

# layout for creating wordcloud with text.
layout(matrix(c(1, 2), nrow=2), heights=c(1, 4))
layout.show(1)
par(mar=rep(0, 4))


## positive word cloud

pos.words <- NULL
pos.words <-  match(c(names(w)), c(pos))
pos.words <-  !is.na(pos.words)
View(pos.words)
freq_pos <- w[pos.words]
View(freq_pos)

pos.v <- data.frame(word = names(freq_pos) , freq = freq_pos)


layout(matrix(c(1, 2), nrow=2), heights=c(1, 4))
par(mar=rep(0,4))

plot.new()
text(x=0.5, y=0.5, "Positive Words")

wordcloud(names(freq_pos), freq=w, min.frq = 10,
          max.words=150,
          random.order=FALSE, rot.per=0.35,colors=brewer.pal(9,"Blues"),
          scale = c(4,0.5))

## top 10 most frequent words used 
ggplot(pos.v[1:10,],aes(x=word,y=freq))+geom_bar(stat = 'identity',fill= "#DF1234")+
  theme(axis.text.x = element_text(angle = 90))+ylab("Word Frequencies")+
  ggtitle("Top 10 most frequent Positive Words")+theme(plot.title = element_text(hjust = 0.5))


plot.new()
text(x=0.5, y=0.5, "Negative Words")


## negitive word cloud
neg.words <- NULL
neg.words <-  match(c(names(w)), c(neg))
neg.words <-  !is.na(neg.words)
View(neg.words)
freq_neg <- w[neg.words]
View(freq_neg)

neg.v <- data.frame(word = names(freq_neg) , freq = freq_neg)

wordcloud(names(freq_neg), freq=w, min.frq = 10, 
          max.words=150, 
          random.order=FALSE, rot.per=0.30,colors=brewer.pal(6,"OrRd"),
          scale = c(5,0.5))

## top 10 most frequent words used 
ggplot(neg.v[1:10,],aes(x=word,y=freq))+geom_bar(stat = 'identity',fill= "#CC1554")+
  theme(axis.text.x = element_text(angle = 90))+ylab("Word Frequencies")+
  ggtitle("Top 10 most frequent Negative Words")+theme(plot.title = element_text(hjust = 0.5))


rm(tdm)

dtm <- DocumentTermMatrix(corpusdd)
dtm <- as.matrix(dtm)
rowTotals = NULL
rowTotals <- apply(dtm , 1, sum)
dtm.new   <- dtm[rowTotals> 0, ]
dtm.new[1:10,1:20]

## 10 topics of the data
lda <- LDA(dtm.new,10)
topic_terms <- terms(lda,10)
topic_terms


## sentiment analysis

s_vect <- get_sentiment(top10dd,method = "syuzhet")
head(s_vect,10)
summary(s_vect)
senti_dt <- get_nrc_sentiment(top10dd)
head(senti_dt,10)

td1 <- data.frame(t(senti_dt))
View(td1)
td_new1 <- data.frame(rowSums(td1[2:50]))
View(td_new1)

names(td_new1)[1] <- "count"
td_new1 <- cbind("sentiment" = rownames(td_new1), td_new1)

rownames(td_new1) <- NULL
td_nw2<-td_new1[1:8,]
View(td_nw2)

## Survey sentiments

quickplot(sentiment, data=td_nw2, weight=count, geom="bar", fill=sentiment, ylab="count")+
  ggtitle("Survey sentiments")+
  theme(axis.text.x = element_text(angle = 45))+theme(plot.title = element_text(hjust = 0.5))

## Emotions in Text
barplot(
  sort(colSums(prop.table(senti_dt[, 1:8]))), 
  horiz = TRUE, 
  cex.names = 0.7, 
  las = 1, 
  main = "Emotions in Text", xlab="Percentage"
)


# ## word cloud for condition
# ## top 5 condition
# top5cond <- as.data.frame(sort(table(data$condition),decreasing=TRUE)[1:5])
# names(top5cond)[c(1,2)] <- c("condition","total_count")
# top5condData <- data[data$condition %in% top5cond[,"condition"] & data$rating > 8,] 
# View(top5condData)
# 
# write.table(top5condData[,"review"],file="top5cond.txt",row.names = F)
# top5cd <- readLines("top5cond.txt")
# 
# corpuscd <- top5cd
# corpuscd <- Corpus(VectorSource(corpuscd))
# corpuscd <- tm_map(corpuscd , tolower)
# corpuscd <- tm_map(corpuscd , removePunctuation)
# corpuscd <- tm_map(corpuscd , removeNumbers)
# corpuscd <- tm_map(corpuscd , removeWords , stopwords("english"),stop)
# corpuscd <- tm_map(corpuscd , stripWhitespace)
# corpuscd <- tm_map(corpuscd , stemDocument)
# inspect(corpuscd[1:5])
# length(corpuscd)
# 
# tdm_cd <- TermDocumentMatrix(corpuscd)
# tdm_cd <- as.matrix(tdm_cd)
# rowTotals_cd <- apply(tdm_cd , 1, sum)
# tdm.new.cd   <- tdm_cd[rowTotals_cd> 0, ]
# tdm.new.cd[1:10,1:20]
# 
# 
# w1 <- sort(rowSums(tdm.new.cd) , decreasing = TRUE)
# View(names(w1))
# v1 <- data.frame(word = names(w1) , freq = w1)
# 
# ## mixed word cloud
# wordcloud(words = names(w1) , freq = w1,
#           max.words = 600 , min.freq = 6,
#           scale = c(8,0.3),rot.per = 0.7,
#           colors = w)


word_data <- data[data$usefulCount>60,]
dim(word_data)
index <- sample(3,nrow(word_data),replace=TRUE,prob = c(3,5,2)) 
dt <- word_data[index==3,]
dim(dt)

write.table(dt[,"review"],file="data.txt",row.names = F)
corpus_clean <- readLines("data.txt")

corpus_data <- corpus_clean
corpus_data <- Corpus(VectorSource(corpus_data))
corpus_data <- tm_map(corpus_data , tolower)
corpus_data <- tm_map(corpus_data , removePunctuation)
corpus_data <- tm_map(corpus_data , removeNumbers)
corpus_data <- tm_map(corpus_data , removeWords , c(stopwords("english"),stop))
corpus_data <- tm_map(corpus_data , stripWhitespace)
corpus_data <- tm_map(corpus_data , stemDocument)
inspect(corpus_data[1:5])
length(corpus_data)

tdm1 <- TermDocumentMatrix(corpus_data)

## correlations 
findAssocs(tdm1,"fear",0.2)
findAssocs(tdm1,"work",0.1)
findAssocs(tdm1,"life",0.3)

tdm1 <- as.matrix(tdm1)
rowTotals1=NULL
rowTotals1 <- apply(tdm1 , 1, sum)
tdm.new1   <- tdm1[rowTotals1> 0, ]
tdm.new1[1:10,1:20]


w1 <- sort(rowSums(tdm.new1) , decreasing = TRUE)
View(names(w1))
v1<-NULL
v1 <- data.frame(word = names(w1) , freq = w1)

## combined/mixed word cloud
plot.new()
text(x=0.5, y=0.5, "mixed cloud")
wordcloud(words = names(w1) , freq = w1,
           max.words = 600 , min.freq = 2,max.freq = 6,
           scale = c(8,0.3),rot.per = 0.7,
           colors = w)

## positive word cloud
pos.words <- NULL
pos.words <-  match(c(names(w1)), c(pos))
pos.words <-  !is.na(pos.words)
View(pos.words)
freq_pos <- NULL
freq_pos <- w1[pos.words]
View(freq_pos)

plot.new()
text(x=0.5, y=0.5, "Positive")

wordcloud(names(freq_pos), freq=w1, min.frq = 10, 
          max.words=150, 
          random.order=FALSE, rot.per=0.35,colors=brewer.pal(8,"Blues"),
          scale = c(6,0.7))

plot.new()
text(x=0.5, y=0.5, "Negative")
## negative word cloud
neg.words <- NULL
neg.words <-  match(c(names(w1)), c(neg))
neg.words <-  !is.na(neg.words)
View(neg.words)
freq_neg <- w1[neg.words]
View(freq_neg)
wordcloud(names(freq_neg), freq=w1, min.frq = 10, 
          max.words=150, 
          random.order=FALSE, rot.per=0.30,colors=brewer.pal(6,"OrRd"),
          scale = c(6,0.7))

## top 20 most frequent words used 
ggplot(v1[1:20,],aes(x=word,y=freq))+geom_bar(stat = 'identity',fill= "lightgreen")+
  theme(axis.text.x = element_text(angle = 90))+ylab("Word Frequencies")+
  title("Top 20 most frequent words")

plot.new()

rm(tdm1)

dtm1 <- DocumentTermMatrix(corpus_data)
dtm1 <- as.matrix(dtm1)
rT = NULL
rT <- apply(dtm1 , 1, sum)
dtm.new1   <- dtm1[rT > 0, ]
dtm.new1[1:10,1:20]

## 10 topics of the data

# lda_dt <- LDA(dtm.new1,10)
# term <- terms(lda_dt,10)
# term

## sentiment analysis

s_vec <- get_sentiment(corpus_clean,method = "syuzhet")
senti_data <- get_nrc_sentiment(corpus_clean)
head(senti_data,10)

td <- data.frame(t(senti_data))
View(td)
td_new <- data.frame(rowSums(td[2:50]))
View(td_new)

names(td_new)[1] <- "count"
td_new <- cbind("sentiment" = rownames(td_new), td_new)

rownames(td_new) <- NULL
td_new2<-td_new[1:8,]
View(td_new2)

## Survey sentiments

quickplot(sentiment, data=td_new2, weight=count, geom="bar", fill=sentiment, ylab="count")+
  ggtitle("Survey sentiments")+
  theme(axis.text.x = element_text(angle = 45))+theme(plot.title = element_text(hjust = 0.5))

## Emotions in Text
barplot(
  sort(colSums(prop.table(senti_data[, 1:8]))), 
  horiz = TRUE, 
  cex.names = 0.7, 
  las = 1, 
  main = "Emotions in Text", xlab="Percentage"
)

